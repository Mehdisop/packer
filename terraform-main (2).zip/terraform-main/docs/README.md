# New DC Euronext Automation with Terraform

This repository is for the use cases implemented with Terraform for Oneview and VMware.

## Developers

VMWare:
- Oliver Desaphy
- Nicolas Portais

Oneview:
- Wayne Curtis
- Claire Hayard

## Improvements
### Oneview
- Use Vault to get sensitive variables (Oneview password, ip address)
- There will be multiple environment to consider, Oneview IP address will not be the same and cannot be considered as constant in the tfvars file
- To handle dependencies, use modules
- Error handling (check data)