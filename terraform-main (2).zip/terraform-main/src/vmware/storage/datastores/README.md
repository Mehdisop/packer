## ** VMware DRS Terraform module**
### Euronext Usecase : 
VMware-10-manage-datastores

### Description:
- This Terraform module manages datastores

### Workflow Pre-requistes : 
- vCenter server
- vCenter target Datacenter object is created
- vCenter vSphere HA cluster is created
- The ESXi Hosts are present into the vCenter Inventory and included into the vSphere HA cluster
- The disk devices are presented to ESXi Hosts

### Workflow Steps :
- Retrieve data source for:
    - Datacenter
    - vSphere HA Cluster
    - Hosts id
    - Available disk devices filtered by the pattern
- Creation of a flatten object with:
    - hostname : hostname of the ESXi Host
    - datastore : Datastore name
    - device : device search by the index of the datastore
    - host_system_id : host-id
- Create the Datastores

### Usage Example

```
$ cd src/vmware/storage/datastores
$ terraform plan -var-file=example.tfvars
$ terraform apply -var-file=example.tfvars
```

### Variables

| Variable name        | Description | Type | Default Value |
|----------------------|-------------|------|---------------|
| `vsphere_server` | vCenter Server address| string ||
| `vsphere_user` | vCenter Server username | string ||
| `vsphere_password` | vCenter Server password | string ||           
| `vsphere_ssl` | vCenter Server accept self signed certificate | bool | true |
| `vsphere_dc_name` | vSphere datacenter name | string ||
| `vsphere_cluster_name` | vSphere cluster Name | string ||
| `vsphere_storage_filter` | Filter pattern for disk device to use ||
| `vsphere_datastores` | Map of Objects (see example below) ||


### An example of a tfvars file

You will find below an example how to create a Host Groups :
#### create a tfvars file with:
##### the Datacenter Name
```
// DC Name
vsphere_dc_name ="DC-EURONEXT"
```
##### The name of the vSphere HA cluster name
```
// vSphere HA name
vsphere_cluster_name="Cluster-HA"
```
##### Map of Datastore name per Host
- ESXi hostname as key of the datastores Object
- datastores object:
    - 0 = "datastore name 0"
    - 1 = "datastore name 1"
    - ...
```
vsphere_datastores = {
    "esx70-1.local" = {
            datastores = {
                0 = "Datastore01"
                1 = "Datastore02"
            },
    },
    "esx70-2.local" = {
            datastores = {
                0 = "Datastore03"
                1 = "Datastore04"
            } 
    }          
}
```