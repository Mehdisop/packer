# [0.1]
### Release date
20210616

### Notes
- VMware-10-manage-datastores. Manage Datastores