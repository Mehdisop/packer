# [0.2] 
### Release date
20210531

### Notes
- first review with Euronext

### Bug fixes and enhancements
- kickstart template was refactored to support Terraform list type for DNS Servers, DNS Search Domain and DNS NTP Servers
- Adding input variables to shell script ```geniso.sh```
- Documentation (```README.md, REQUIREMENTS.md, RELEASENOTES.md```)

# [0.1]
### Release date
20210528

### Notes
- first commit