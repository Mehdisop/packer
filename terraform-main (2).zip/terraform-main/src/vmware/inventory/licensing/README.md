## ** VMware License Management Terraform  module**
### Euronext Usecase : 
VMware-9-license-management

### Description:
This Terraform module manages VMware vSphere License keys.

### Workflow Pre-requistes : 
- Network connectivity to vCenter Server.
- Initiate the terraform init, plan and apply command in the use case folder
- A tfvars file has been generated

### Workflow Steps :
- Add/Remove VMware vSphere License Keys into/from vCenter.

### Usage Example

```
$ cd src/vmware/inventory/licensing
$ terraform plan -var-file=example.tfvars
$ terraform apply -var-file=example.tfvars
```

### Variables

| Variable name        | Description | Type | Default Value |
|----------------------|-------------|------|---------------|
| `vsphere_server` | vCenter Server address| <pre>string</pre> ||
| `vsphere_user` | vCenter Server username | <pre>string</pre> ||
| `vsphere_password` | vCenter Server password | <pre>string</pre> ||
| `vsphere_ssl` | vCenter Server accept self signed certificate | <pre>bool</pre> | <pre>true</pre> ||
| `vsphere_licenses` | VMware vSphere License Keys and associated comment| <pre>list(object({
            license_key = string
            comment = string
        }
    ))</pre> | <pre>[]</pre>|

### vsphere_licenses variable example value

<pre>
vsphere_licenses = [
    {
        license_key = "XXXXX-XXXXX-XXXXX-00000-00001"
        comment = "My License Key 1"
    },
    {
        license_key = "XXXXX-XXXXX-XXXXX-00000-00002"
        comment = "My License Key 2"
    }
]
</pre>




