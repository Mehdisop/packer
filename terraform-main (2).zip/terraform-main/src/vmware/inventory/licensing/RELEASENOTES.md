# [0.1]
### Release date
20210611

### Notes
- VMware-9-license-management. Initial version