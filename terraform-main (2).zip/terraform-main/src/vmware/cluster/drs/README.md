## ** VMware DRS Terraform module**
### Euronext Usecase : 
VMware-10-manage-drs

### Description: This Terraform module manages DRS and it manages :
- DRS Host Groups 
- DRS VM Groups
- VM-to-Host *should/must run* rule
- Anti VM-to-Host *should/must run* rule

### Workflow Pre-requistes : 
- vCenter server
- vCenter target Datacenter object is created
- vCenter vSphere HA cluster is created
- The ESXi Hosts are present into the vCenter Inventory and included into the vSphere HA cluster
- VMs associated to rules are present into the vCenter Inventory

### Workflow Steps :
- Retrieve data source for:
    - Datacenter
    - vSphere HA Cluster
    - Hosts id
    - VMs uuid
- Create DRS Host Groups
- Create DRS VMs Groups
- Create VM-to-Host rule
- Create Anti VM-to-Host rule

### Usage Example

```
$ cd src/vmware/cluster/drs/host_group
$ terraform plan -var-file=example.tfvars
$ terraform apply -var-file=example.tfvars
```

### Variables

| Variable name        | Description | Type | Default Value |
|----------------------|-------------|------|---------------|
| `vsphere_server` | vCenter Server address| string ||
| `vsphere_user` | vCenter Server username | string ||
| `vsphere_password` | vCenter Server password | string ||           
| `vsphere_ssl` | vCenter Server accept self signed certificate | bool | true |
| `vsphere_dc_name` | vSphere datacenter name | string ||
| `vsphere_cluster_name` | vSphere cluster Name | string ||
| `vsphere_all_hosts` | Map of all ESXi fqdn hosts participating to the Host Groups | map ||
| `vsphere_all_vms` | Map of ALL VMs name participated to VM-to-Host rule | map ||
| `vsphere_drs_host_groups` | List of Object ||
| `vsphere_drs_vm_groups` | List of Object ||
| `vsphere_drs_vm_host_rules` | List of Object ||
| `vsphere_drs_anti_vm_host_rules` | List of Object ||
| `vsphere_drs_vm_override` | List of Object ||

### An example of a tfvars file

You will find below an example how to create a Host Groups :
#### create a tfvars file with:
##### the Datacenter Name
```
// DC Name
vsphere_dc_name ="DC-EURONEXT"
```
##### The name of the vSphere HA cluster name
```
// vSphere HA name
vsphere_cluster_name="Cluster-HA"
```
##### A map with the list of Host included into the vSphere HA Cluster
```
// List of Hosts
vsphere_all_hosts = {
    "esx70-1.local" = 1
    "esx70-2.local" = 2
}
```
##### List of Host Groups Object with:
- the name of the Host Group
- The list of the associated hosts
```
vsphere_drs_host_groups = [
    {
        // Name of the Host Group
        name = "Host Group 1"
        // List of the Hosts Members
        hosts = ["esx70-1.local"]
    },
    {
        name = "Host Group 2"
        hosts = ["esx70-1.local"]
    },
    {
        name = "Host Group All"
        hosts = ["esx70-1.local", "esx70-2.local"]
    }    
]
```
##### List of the VM Groups Object with:
- the name of the VM Group
- The list of the associated VMs
```
vsphere_drs_vm_groups = [
    {
        // Name of the VM Group
        name = "VMs Group 1"
        // List of the VMs Members
        vms = ["VM1"]
    },
    {
        name = "VMs Group 2"
        vms = ["VM2"]
    },
    {
        name = "All VMs"
       vms = ["VM1", "VM2", "VM3"]
    }    
]
```
##### List of VMs-to-Host Object rule with:
- name of the rule
- hostgroup name
- vm group name
- mandatory (bool) : Must Run == true || Should run == false

```
// DRS: VMs-to-Host Rules
vsphere_drs_vm_host_rules = [
    {
        // Name of the Host Group
        name = "VM-Host Rule 1"
        host_group_name = "Host Group 1"
        vm_group_name = "VMs Group 1"
        mandatory = true
    },
    {
        name = "VM-Host Rule 2"
        host_group_name = "Host Group 2"
        vm_group_name = "VMs Group 2"
        mandatory = false
    },
    {
        name = "VM-Host Rule All"
        host_group_name = "Host Group All"
        vm_group_name = "All VMs"
        mandatory = false
    }    
]
```
##### List of Anti VMs-to-Host Object rule with:
- name of the rule
- hostgroup name
- vm group name
- mandatory (bool) : Must Run == true || Should run == false

```
// DRS Anti VMs-to-Host Rules
vsphere_drs_anti_vm_host_rules = [
    {
        // Name of the Host Group
        name = "VM1 must Not run on Host Groups 1"
        host_group_name = "Host Group 1"
        vm_group_name = "VMs Group 1"
        mandatory = true
    }
]
```
##### List of VM Override settings Object with:
- drs_enabled : Bool
- drs_automation_level: manual, partiallyAutomated, or fullyAutomated
- vm_name: name of the virtual machine 
```
// DRS VM Override Settings
vsphere_drs_vm_override = [
    {
        drs_enabled = false
        drs_automation_level = "manual" // manual, partiallyAutomated, or fullyAutomated
        vm_name = "VM1"
    },
    {
        drs_enabled = true
        drs_automation_level = "fullyAutomated" // manual, partiallyAutomated, or fullyAutomated
        vm_name = "VM2"
    }
]
```
