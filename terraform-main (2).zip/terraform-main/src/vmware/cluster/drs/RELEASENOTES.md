# [0.1]
### Release date
20210614

### Notes
- VMware-10-manage-drs. Manage DRS Rules and Groups

# [0.2]
- Add VM Override Settings