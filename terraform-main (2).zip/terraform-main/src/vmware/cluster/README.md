## ** VMware vSphere Cluster Terraform module**
### Euronext Usecase : 
VMware-8-vcenter-cluster

### Description:
This Terraform module manages vSphere cluster 

### Workflow Pre-requistes : 
- vCenter server
- vCenter target Datacenter object is created

### Workflow Steps :
- Fetch the SSL thumbprints for each vSphere host
- Create Cluster with DRS and HA options
- Add vSphere hosts to vSphere Cluster

### Usage Example

```
$ cd src/vmware/cluster
$ terraform plan -var-file=example.tfvars
$ terraform apply -var-file=example.tfvars
```

### Variables

| Variable name        | Description | Type | Default Value |Example                             |
|----------------------|-------------|------|---------------|------------------------------------|
| vsphere_server | vCenter Server address| string | | vcenter1.local |
| vsphere_user | vCenter Server username | string | | administrator@vsphere.local | 
| vsphere_password | vCenter Server password | string |||                
| vsphere_ssl | vCenter Server accept self signed certificate | bool | true ||     
| vsphere_host_login | ESXi username | string | | root |
| vsphere_host_password | ESXi password | string | | root |
| vsphere_datacenter | vSphere datacenter name | string | | dc1 | 
| vsphere_hosts | Map of ESXi fqdn hosts | map | | <pre>{<br>    "esxbuild1.domain.net" = 1<br>    "esxbuild2.domain.net" = 2<br>}</pre> |
| vsphere_cluster_name | vSphere cluster Name | string | | cluster1 |
| drs_enabled | DRS Enabled ? | bool | true | |
| drs_automation_level | DRS Automation Level | string | manual | |
| drs_migration_threshold | DRS Migration Threshold | number | 3 | | 
| drs_enable_vm_overrides | DRS Enable VM overrides ? | bool | true | |
| drs_enable_predictive_drs | DRS Enable Predictive DRS ? | bool | false | |
| drs_advanced_options | DRS Advanced Options | map | {} | | 
| ha_enabled | HA Enabled ? | bool | true | |
| ha_host_monitoring | HA Host Monitoring ? (Determines whether HA restarts virtual <br>machines after a host fails) | string | enabled | |
| ha_vm_restart_priority | HA VM Restart Priority (The default restart priority for <br>affected virtual machines when vSphere detects a host failure) | string | medium | |
| ha_host_isolation_response | HA Host Isolation Response | string | none | |
| ha_vm_restart_timeout | HA VM Restart Timeout in seconds | number | 600 | |
| ha_advanced_options | HA Advanced Options | map | {} | | 
