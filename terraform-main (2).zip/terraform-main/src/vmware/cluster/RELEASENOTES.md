# [0.1]
### Release date
20210608

### Notes
- VMware-8-vcenter-cluster - first version