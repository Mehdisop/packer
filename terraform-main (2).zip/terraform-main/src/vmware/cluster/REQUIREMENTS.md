## ** Requirements **

### Euronext Usecase : 
VMware-8-vcenter-cluster

#### Terraform automation server
- Terraform >= 0.15.1
- network connectivity to target vCenter Server

##### Terraform providers
- vsphere (https://registry.terraform.io/providers/hashicorp/vsphere)