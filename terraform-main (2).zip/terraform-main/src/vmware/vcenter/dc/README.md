## ** VMware vCenter DC Terraform module**
### Euronext Usecase : 
VMware-3-manage-vsphere-datacenter

### Description:
This Terraform module creates the Datacenter object into the vCenter.

The name and the optional folder are provided as variables.

### Workflow Pre-requistes : 
- vCenter is deployed and available on the Network
- (optional) The datacenter folder is created first

### Workflow Steps :
- Create the Datacenter object

### Usage Example

```
$ cd src/vmware/vcenter/dc
$ terraform init
$ terraform plan -var-file=example.tfvars
$ terraform apply -var-file=example.tfvars
```

### Variables

| Variable name        | Description | Type | Default Value |Example                             |
|----------------------|-------------|------|---------------|------------------------------------|
|`name`|name of the Datacenter Object|String||`DC-EURONEXT`|
|`folder`|(optional) folder where the Datacenter object must be create. The folder must be created before.|String|`/`|`Italia`|