## ** Requirements **

### Euronext Usecase : 
VMware-3-manage-vsphere-datacenter

#### Terraform automation server
- Terraform >= 0.15.1
- network connectivity to target vCenter Server

##### Terraform providers
- vsphere (https://registry.terraform.io/providers/hashicorp/vsphere)