## ** VMware vCenter Terraform Deployment module **
### Euronext Usecase:
VMware-2-vCenter-provisionning

### Description:
This Terraform module deploys vCenter OVA on an existing ESXi Host.

The configuration of the json deployment template are provided as variables.

### Workflow Pre-requisites:
- The vCenter installation ISO has been down,loaded and extracted into a local directory of the Terraform server.
- DNS resolution and reverse of the FQDN Hostname

### Workslow Steps:
- Creation of the json file using the Terraform template based on the tfvars file
- Provisionning of the vCenter using the generated json file

### Usage Example:

```
$ cd src/vmware/vcenter/deploy
$ terraform plan -var-file=deploy-vcenter.tfvars
$ terraform apply -var-file=deploy-vcenter.tfvars
```

### Variables

| Variable name    | Description | Type | Default Value |
|------------------|-------------|------|---------------|
|`template_file`|JSON template file to use for vcsa-cli-installer|String|./templates/embedded_vCSA_on_ESXi.json|
|`generated_config`|Generated JSON file|String|./build/generated.json|
|`installcmd`|Path to the vcsa-deploy command|String||
|`esx_hostname`|ESXi Hostname or IP of the ESXi Host used to deploy vCenter|String||
|`esx_username`|ESXi login|String|root|
|`esx_password`|ESXi password|String||
|`esx_portgroup`|ESXi Network PortGroup|String|VM Network|
|`esx_datastore`|ESXi Datastore|String||
|`vcenter_thin_disk_mode`|Create Thin provisioning VMDK|Bool|true|
|`vcenter_deployment_option`|vCenter Deployment Sizing|String|tiny|
|`vcenter_ceip_enabled`|Enroll to the VMware's Customer Experience Improvement Program|Bool|false|
|`vcenter_vm_name`|VM name|String||
|`vcenter_fqdn`|vCenter Hostname FQDN|String||
|`vcenter_net_ip`|vCenter Network IP Address|String||
|`vcenter_net_prefix`|vCenter Network IP Mask|String|24|
|`vcenter_net_gateway`|vCenter Network IP Gateway|String||
|`vcenter_dns`|DNS Servers separated by comma character|String||
|`vcenter_ntp`|NTP Servers separated by comma character|String||
|`vcenter_os_password`|vCenter Operating System root password|String||
|`vcenter_sso_password`|vCenter SSO Administrator password|String||
|`vcenter_sso_domain`|vCenter SSO Domain|String|vsphere.local|


