## ** Requirement **

### Euronext Usecase:
VMware-2-vCenter-provisioning

#### Terraform automation server
- Terraform >= 0.15.1
- network connectivity to VMware ESXi Host
- Copy of the vCenter installation ISO available on the VMware Website: https://my.vmware.com/en/web/vmware/downloads/info/slug/datacenter_cloud_infrastructure/vmware_vsphere/7_0

#### Installation of the requirement

### Copy of the vCenter ISO content

```
$ mount -o loop [path_to]/VMware-VCSA-all-7.0.2-17958471.iso [path_to_mountpoint]
$ cp -a [path_to_mountpoint]/* [path_to_local_directory]
...
```
