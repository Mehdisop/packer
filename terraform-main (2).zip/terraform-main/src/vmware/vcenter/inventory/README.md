## ** VMware Host Terraform Deployment module**
### Euronext Usecase : 
VMware-4-vcenter-inventory-tags

### Description:
This Terraform manages vSphere Tags. 

### Workflow Pre-requistes : 
- Network connectivity to vCenter Server.
- Initiate the terraform init, plan and apply command in the use case folder
- A tfvars file has been generated

### Workflow Steps :
- Creation of vSphere Tag categories
- Creation of vSphere Tags

### Usage Example

```
$ cd src/vmware/inventory/tags
$ terraform plan -var-file=example.tfvars
$ terraform apply -var-file=example.tfvars
```

### Variables

| Variable name        | Description | Type | Default Value |Example                             |
|----------------------|-------------|------|---------------|------------------------------------|
| vsphere_server | vCenter Server address| <pre>string</pre> | | vcenter1.local |
| vsphere_user | vCenter Server username | <pre>string</pre> | | administrator@vsphere.local |
| vsphere_password | vCenter Server password | <pre>string</pre> |||
| vsphere_ssl | vCenter Server accept self signed certificate | <pre>bool</pre> | <pre>true</pre> ||
| vsphere_tag_category | vSphere Tag Categories | <pre>list(<br>  object(<br>    {<br>        name = string<br>        description = string<br>        cardinality = string<br>        object_types = list(string)<br>    }<br>  )<br>)</pre> | <pre>[ ]</pre> |
| vsphere_tag | vSphere Tags | <pre>list(<br>  object(<br>    {<br>      name = string<br>      description = string<br>      category = string<br>    }<br>  )<br>)</pre> | <pre>[ ]</pre> |