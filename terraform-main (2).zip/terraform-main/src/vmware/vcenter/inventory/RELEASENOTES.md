# [0.2]
### Release date
20210602

### Notes
- Module was refactored with usage of list of object types for categories (vsphere_tag_category) and tags (vsphere_tag)
- Documentation updates
- new versions.tf file for providers dependencies.

# [0.1]
### Release date
20210601

### Notes
- VMware-4-vcenter-inventory-tags - first version