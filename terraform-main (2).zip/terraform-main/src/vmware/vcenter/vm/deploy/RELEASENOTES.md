# [0.1]
### Release date
20210608

### Notes
- VMware-7-vCenter-deploy-vm-from-ovf