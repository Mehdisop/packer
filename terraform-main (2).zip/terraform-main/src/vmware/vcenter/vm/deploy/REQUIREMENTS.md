## ** Requirements **

### Euronext Usecase : 
VMware-7-vCenter-deploy-vm-from-ovf

#### Terraform automation server
- Terraform >= 0.15.1
- network connectivity to target vCenter Server

##### Terraform providers
- vsphere 2.0.0 (https://registry.terraform.io/providers/hashicorp/vsphere)