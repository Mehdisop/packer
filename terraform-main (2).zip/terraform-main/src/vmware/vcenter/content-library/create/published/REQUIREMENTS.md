## ** Requirements **

### Euronext Usecase : 
VMware-6-vCenter-manage-contentlibrary

#### Terraform automation server
- Terraform >= 0.15.1
- network connectivity to target vCenter Server

##### Terraform providers
- vsphere 1.26.0 (https://registry.terraform.io/providers/hashicorp/vsphere)