## ** VMware vCenter Content Library Terraform  module**
### Euronext Usecase : 
VMware-6-vCenter-manage-contentlibrary

### Description:
This Terraform manages vSphere Content Library. This module permits to subscribe to a remote Content Library.

### Workflow Pre-requistes : 
- Network connectivity to vCenter Server.
- Initiate the terraform init, plan and apply command in the use case folder
- A tfvars file has been generated

### Workflow Steps :
- Creation of vSphere Content Library.

### Usage Example

```
$ cd src\vmware\vcenter\content-library\create\published
$ terraform plan -var-file=example.tfvars
$ terraform apply -var-file=example.tfvars
```

### Variables

| Variable name        | Description | Type | Default Value |Example                             |
|----------------------|-------------|------|---------------|------------------------------------|
| `vsphere_server` | vCenter Server address| <pre>string</pre> | | vcenter1.local |
| `vsphere_user` | vCenter Server username | <pre>string</pre> | | administrator@vsphere.local |
| `vsphere_password` | vCenter Server password | <pre>string</pre> |||
| `vsphere_ssl` | vCenter Server accept self signed certificate | <pre>bool</pre> | <pre>true</pre> ||
| `vsphere_dc_name` | vCenter Datacenter name | string ||
| `vsphere_contentlibrary_name` | vSphere Content Library name| string |||
| `vsphere_contentlibrary_description` | vSphere Content Library Description| string |||
| `vsphere_contentlibrary_backinstore_name` | vSphere Content Library Datastore name| string |||
| `vsphere_contentlibrary_subscription` | vSphere Content Library Publication Object| <pre>object(
        {
            subscription_url = string
            authentication_method = string
            username = string
            password = string
            automatic_sync = bool
            on_demand = bool
        }</pre> |<pre>{
            subscription_url = ""
            authentication_method = "NONE"
            username = ""
            password = ""
            automatic_sync = true
            on_demand = false          
    }</pre>||



