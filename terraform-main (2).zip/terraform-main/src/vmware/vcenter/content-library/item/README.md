## ** VMware vCenter Content Library Terraform  module**
### Euronext Usecase : 
VMware-6-vCenter-manage-contentlibrary

### Description:
This Terraform module manages vSphere Content Library. This module permits to publish a list of items (ovf, ova or iso) into the Content Library.

### Workflow Pre-requistes : 
- Network connectivity to vCenter Server.
- Initiate the terraform init, plan and apply command in the use case folder
- A tfvars file has been generated

### Workflow Steps :
- Upload items into the Content Library.

### Usage Example

```
$ cd src\vmware\vcenter\content-library\item\
$ terraform plan -var-file=example.tfvars
$ terraform apply -var-file=example.tfvars
```

### Variables

| Variable name        | Description | Type | Default Value |Example                             |
|----------------------|-------------|------|---------------|------------------------------------|
| `vsphere_server` | vCenter Server address| <pre>string</pre> | | vcenter1.local |
| `vsphere_user` | vCenter Server username | <pre>string</pre> | | administrator@vsphere.local |
| `vsphere_password` | vCenter Server password | <pre>string</pre> |||
| `vsphere_ssl` | vCenter Server accept self signed certificate | <pre>bool</pre> | <pre>true</pre> ||
| `vsphere_dc_name` | vCenter Datacenter name | string ||
| `vsphere_contentlibrary_name` | vSphere Content Library name| string |||
| `vsphere_contentlibrary_items` | vSphere Content Library Items Object| <pre>list(object({
            name = string
            description = string
            type = string // iso, ovf or ova
            file_url  = string            
        }
    ))</pre> |<pre>[]</pre>||



