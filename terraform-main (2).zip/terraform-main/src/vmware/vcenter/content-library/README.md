## ** VMware vCenter Content Library Terraform  module**
### Euronext Usecase : 
VMware-6-vCenter-manage-contentlibrary

### Description:
This Terraform module manages vSphere Content Library.

This modules permits to:
- create a Content Library 
    - Into the folder create/published: Create a published local Content Library
    - Into the folder create/subscripted: Create a subscripted Content Library from a remote Content Library

    See README into these directories for more info.
    
- upload items into the Content Library

See the README into these directories for more details.