﻿## ** OneView Server Profile Template creation module**
### Euronext Usecase :
2-Server_Profile_Template: Create a Server Profile Template with the Euronext requirements

### Description:
The Server Profile Template module creates a new (or updated) Server Profile Template that includes boot, bios, network connections, and other option from the LLD requirements.

The configuration of the Server Profile Template is provided as variables. The editable file for variables is the "variables.tfvars" file.

### Workflow Pre-requistes :
- The Synergy environment must have the necessary objects to build a Server Profile Template. The template includes are requirement of an Enclosure Group name. The Enclosure Group (LE) is part of a Logical Enclosure which also has Logical Interconnect Groups (LIGs). The networks referenced in this Server Profile Template script must:
    • Exist
    • Available on the Logical Interconnect
    • Available on the Logical Interconnect Group
Here is a sample error message produced for a network that did not have the requirements:
Error: The network ({"name":"TUN1WMV", "uri":"/rest/ethernet-networks/665075a5-0f59-4bd6-a86e-97b28540b498"}) for the connection on physical port Mezzanine (Mezz) 3:2 is not available on logical interconnect group {"name":"LIG-VC", "uri":"/rest/logical-interconnect-groups/cf04be31-07da-40fb-a1ea-520f65401c38"}. 
Select a different network that is available on both the logical interconnect and logical interconnect group or remove the conflicting network from the connection.

- Initiate the terraform init, plan and apply command in the use case folder (2-Server_Profile_Template). 
Network interfaces (Ethernet and Fibre Channel) must be created/existing add network connections to the template.

### Workflow Steps :
- If necessary, add or update the variables.tfvars file to change the name and other parameters to be included
- Create the network interfaces (if not previously created)

### Usage Example

Using the Terraform SDK Docker image

```
$ docker run -ti --rm -v "/home/ubuntu/Documents/Euronext/newdcautomation/src/oneview:/scripts" hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1 /bin/sh
$ cd /scripts/
$ cd Server-Profile-Templates/2-server-profile-template
$ terraform init
$ terraform plan -var-file="variables.tfvars"
$ terraform apply -var-file="variables.tfvars"
```

### Global Variables

Variables in the variables.tfvars file at the root folder "oneview"

| Variable name        | Comment | Type | Default Value |Example                       |
|----------------------|---------|------|---------------|------------------------------|-------------------------------------|
|`oneview_uri`|OneView URI|https://10.2.1.50/|||
|`oneview_username`|OneView Username|Administrator|||
|`oneview_password`|OneView Password||||
|`oneview_apiversion`|OneView API Version|2600|

### Local Variables

Variables in the variables.tf file

### Improvements

Improvements for future versions of this use-case:
Reference networks by name rather than URI
Update iLO settings as needed by customer
Update BIOS settings as needed by customer





