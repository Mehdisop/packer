Euronext Usecase :

2-server-profile-template

This is an single atomic task to create a Server Profile Template.
v1.0.0

    Initial commit: created the Terraform files (main.tf, variables.tf, variables.tfvars) to create an SPT
    Added the documentation (README.md...)
    Added code to Server Profile Templates
    Added local variables declaration and variables.tfvars for the template resource


Assigning "Local Storage" for a boot drive is not available on the "SY 480 Gen9 1" servers in our testing environment. This is a capability for "Gen10" servers in the customer environment.