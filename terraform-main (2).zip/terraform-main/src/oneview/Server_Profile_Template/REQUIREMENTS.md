## ** Requirements **

### Euronext Usecase :
2-server-profile-template

#### Linux Environment
- Docker

#### Terraform SDK
- Docker image (insert link)
- hpeOneView >= 6.0, <= 6.1
- Terraform = 0.13

### Installation of the requirements:

#### Terraform SDK: Docker image

```
$ docker pull hewlettpackardenterprise/hpe-oneview-sdk-for-terraform
```
