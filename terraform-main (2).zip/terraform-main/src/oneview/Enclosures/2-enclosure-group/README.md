## ** OneView Enclosure Group Provisioning module**
### Euronext Usecase :
2-enclosure-group

### Description:
This Enclosure Group Terraform module creates Enclosure Groups in OneView.

The configuration of the Enclosure Group is provided as variables.

### Workflow Pre-requistes :
- Initiate the terraform init, plan and apply command in the use case folder (2-enclosure-group)

### Workflow Steps :
- If necessary, add or update the variables.tfvars file to change the enclosure group configuration
- Create the enclosure groups

### Usage Example

Using the Terraform SDK Docker image

```
$ docker run -ti --rm -v "/home/ubuntu/Documents/Euronext/newdcautomation/src/oneview:/scripts" hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1 /bin/sh
$ cd /scripts/
$ cd Enclosures/2-enclosure-group
$ terraform init
$ terraform plan -var-file=variables.tfvars
$ terraform apply -var-file=variables.tfvars
```

To destroy the resources created do the following:
```
$ docker run -ti --rm -v "/home/ubuntu/Documents/Euronext/newdcautomation/src/oneview:/scripts" hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1 /bin/sh
$ cd /scripts/
$ cd Enclosures/2-enclosure-group
$ terraform plan -destroy -var-file=variables.tfvars
$ terraform destroy -var-file=.variables.tfvars
```

### Global Variables

Variables in the variables.tfvars file at the root folder "oneview"

| Variable name        | Comment | Type | Default Value |Example                       |
|----------------------|---------|------|---------------|------------------------------|-------------------------------------|
|`oneview_uri`|OneView URI|string|https://10.2.1.50/|||
|`oneview_username`|OneView Username|string|Administrator|||
|`oneview_password`|OneView Password|string||||
|`oneview_apiversion`|OneView API Version|number|2600|||

### Local Variables

Variables defined in the variables.tf file and set in the local variables.tfvars file.

### Improvements
- Handle the IPv4 range parameter with IPs and range name instead of range uris (improvement from SDK needed)
- Set the ip_addressing_mode variable to "IpPool" and then the ip_range_uris accordingly