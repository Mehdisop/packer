## ** OneView Enclosure Group Provisioning module**
### Euronext Usecase :
2-enclosure-group

It is an atomic task to create a Enclosure Group.

## v1.0.0

- Initial commit: created the Terraform files (main.tf, variables.tf) to create Enclosure Groups
- Added the documentation (README.md...)
- Added code to create Enclosure Groups
- Added local variables declaration
- Added a local variables.tfvars file to set the Enclosure Groups configurations
- Added comments in the code for the parameter automatically set to default
- Added comments in the code for parameter ip tange uris (which is not yet set)