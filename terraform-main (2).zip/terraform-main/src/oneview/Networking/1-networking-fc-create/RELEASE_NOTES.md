# ** OneView Fiber Channel Networks Provisioning module**
## Euronext Usecase :
1-networking-Create-fc-network

It is an atomic task to create a single Fiber Channel network.

## v1.0.0
- Initial commit: created a folder to hold the Terraform scripts (main.tf, variables.tf) and the documentation (README.md...)
- Added code to create Fiber Channel networks
- Added local variables declaration
- Added documentation for Fiber Channel network module

## v1.0.1
- Added for each loop and list variables to handle the creation of multiple FC networks
- Updated the REQUIREMENTS.md file with the environment versions needed

## v1.0.2
- Created a local variables.tfvars to set the configuration of FC networks
- Updated the RELEASE_NOTES.md and README.md file