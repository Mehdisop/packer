## ** OneView Fiber Channel Networks Provisioning module**
### Euronext Usecase :
1-networking-Create-fc-network

### Description:
This Fiber Channel Networks Terraform module creates FC networks on OneView.

The configuration of the FC networks are provided as variables.

### Workflow Pre-requistes :
- Initiate the terraform init, plan and apply command in the use case folder (1-networking-fc-create)

### Workflow Steps :
- If necessary, add or update the variables.tfvars file to change the fiber channel networks configuration
- Create the FC networks

### Usage Example

Using the Terraform SDK Docker image

```
$ docker run -ti --rm -v "/home/ubuntu/Documents/Euronext/newdcautomation/src/oneview:/scripts" hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1 /bin/sh
$ cd /scripts/
$ cd Networking/1-networking-fc-create
$ terraform init
$ terraform plan -var-file=variables.tfvars
$ terraform apply -var-file=variables.tfvars
```

To destroy the resources created do the following:
```
$ docker run -ti --rm -v "/home/ubuntu/Documents/Euronext/newdcautomation/src/oneview:/scripts" hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1 /bin/sh
$ cd /scripts/
$ cd Networking/1-networking-fc-create
$ terraform plan -destroy -var-file=variables.tfvars
$ terraform destroy -var-file=variables.tfvars
```

### Global Variables

Variables in the variables.tfvars file

| Variable name        | Comment | Type | Default Value |Example                       |
|----------------------|---------|------|---------------|------------------------------|-------------------------------------|
|`oneview_uri`|OneView URI|https://10.2.1.50/|||
|`oneview_username`|OneView Username|Administrator|||
|`oneview_password`|OneView Password||||
|`oneview_apiversion`|OneView API Version|2600|

### Local Variables

Variables are declared in the variables.tf file and set in the local variables.tfvars file.