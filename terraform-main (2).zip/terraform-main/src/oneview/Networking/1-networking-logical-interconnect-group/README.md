## ** OneView Logical Interconnect Groups Provisioning module**
### Euronext Usecase :
1-networking-lig

### Description:
This Logical Interconnect Group Terraform module creates Logical Interconnect Group (LIG) on OneView.

The configuration of the Logical Interconnect Group are provided as variables.

Terraform verifies the existing underlining hardware when creating the LIG. The LIG configuration must match the harware configuration.
For this first version, we used static variables for the interconnect map and the uplink sets as the tests we done in the HPE lab.

For the other parameters, they keep their default values. All those parameters are indicated in the LLD (Low Level Design) document

### Workflow Pre-requistes :
- Initiate the terraform init, plan and apply command in the use case folder (1-networking-logical-interconnect-group)

### Workflow Steps :
- If necessary, add or update the variables.tfvars file to change the logical interconnect configuration
- Create the logical interconnect group

### Usage Example

Using the Terraform SDK Docker image

```
$ docker run -ti --rm -v "/home/ubuntu/Documents/Euronext/newdcautomation/src/oneview:/scripts" hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1 /bin/sh
$ cd /scripts/
$ cd Networking/1-networking-logical-interconnect-group
$ terraform init
$ terraform plan -var-file=variables.tfvars
$ terraform apply -var-file=variables.tfvars
```

To destroy the resources created do the following:
```
$ docker run -ti --rm -v "/home/ubuntu/Documents/Euronext/newdcautomation/src/oneview:/scripts" hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1 /bin/sh
$ cd /scripts/
$ cd Networking/1-networking-logical-interconnect-group
$ terraform plan -destroy -var-file=variables.tfvars
$ terraform destroy -var-file=.variables.tfvars
```


### Global Variables

Variables in the variables.tfvars file at the root folder "oneview"

| Variable name        | Comment | Type | Default Value |Example                       |
|----------------------|---------|------|---------------|------------------------------|-------------------------------------|
|`oneview_uri`|OneView URI|https://10.2.1.50/|||
|`oneview_username`|OneView Username|Administrator|||
|`oneview_password`|OneView Password||||
|`oneview_apiversion`|OneView API Version|2600|

### Local Variables

Variables defined in the variables.tf file and set in the local variables.tfvars file.

### Improvements

List of improvements to handle for a second version.

- The DownlinkSpeedMode parameter cannot be currently set because not implemented in the SDK
- For the uplink set parameter in the LIG:
    - Handle nested loops to create multiple uplink sets and logical port config (maybe nested dynamic blocs ?)