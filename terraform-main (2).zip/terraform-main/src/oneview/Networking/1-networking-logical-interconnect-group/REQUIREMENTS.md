## ** Requirements **

### Euronext Usecase :
1-networking-lig

#### Linux Environment

- Ubuntu 20.04.2 LTS
- Docker version 20.10.6

#### Terraform SDK
- Docker image (hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1)
- hpeOneView >= 6.0, <= 6.1
- Terraform = 0.13

### Installation of the requirements:

#### Terraform SDK: Docker image

```
$ docker pull hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1
```