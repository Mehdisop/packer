## ** OneView Logical Interconnect Groups Provisioning module**
### Euronext Usecase :
1-networking-lig

It is an atomic task to create a Logical Interconnect Group.

## v1.0.0

- Initial commit: created the Terraform files (main.tf, variables.tf) to create a LIG
- Added the documentation (README.md...)
- Added code to Logical Interconnect Group
- Added local variables declaration
- Added a local variables.tfvars file to set the LIG configurations
- Updated documentation for Logical Interconnect module
- Added a section for improvements in the README.md
- Added validation for some variables in the variables.tf file

## v1.0.1

- Added dynamic block to handle the interconnect map entry template multiple blocks
- Added dynamic block to handle the logical port config multiple blocks in a uplink set
- Updated the improvement section in the README.md for future versions