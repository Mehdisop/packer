## ** OneView Network Set provisioning module**
### Euronext Usecase :
1-networking: Create network set

It is an atomic task to create one or multiple network sets.

## v1.0.0
- Initial commit: created a folder to hold the Terraform scripts (main.tf, variables.tf) and the documentation (README.md...)
- Added code to create a network set
- Added local variables declaration
- Added documentation network set module

## v1.0.1
- Added for each loop and list variables to handle the creation of multiple FC networks
- Created a local variables.tfvars to set the configuration of network sets
- Updated the RELEASE_NOTES.md and README.md file