## ** OneView Network Set provisioning module**
### Euronext Usecase :
1-networking: Create network set

### Description:
This Network Set Terraform module creates multiple network sets based on a list of existing networks in OneView.

The configuration of the Network set is provided as variables, which include network-set name and included networks in the set.

### Workflow Pre-requistes :
- Initiate the terraform init, plan and apply command in the use case folder (1-networking-network-set)

### Workflow Steps :
- If necessary, add or update the variables.tfvars file to change the network-set name and ethernet networks to be included
- Create the network-set

### Usage Example

Using the Terraform SDK Docker image

```
$ docker run -ti --rm -v "/home/ubuntu/Documents/Euronext/newdcautomation/src/oneview:/scripts" hewlettpackardenterprise/hpe-oneview-sdk-for-terraform:v6.1.0-13-OV6.1 /bin/sh
$ cd /scripts/
$ cd Networking/1-networking-network-set
$ terraform init
$ terraform plan -var-file=variables.tfvars
$ terraform apply -var-file=variables.tfvars
```

### Global Variables

Variables in the variables.tfvars

| Variable name        | Comment | Type | Default Value |Example                       |
|----------------------|---------|------|---------------|------------------------------|-------------------------------------|
|`oneview_uri`|OneView URI|https://10.2.1.50/|||
|`oneview_username`|OneView Username|Administrator|||
|`oneview_password`|OneView Password||||
|`oneview_apiversion`|OneView API Version|2600|

### Local Variables

Variables are declared in the variables.tf file and set in the local variables.tfvars file.