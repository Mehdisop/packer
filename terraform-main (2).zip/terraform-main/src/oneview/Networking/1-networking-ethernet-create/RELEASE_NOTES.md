## ** OneView Ethernet Networks Provisioning module**
## Euronext Usecase :
1-networking-Create-ethernet-network

This use case includes the Tunnel network use case.

## v1.0.0
- Initial commit: created a folder to hold the Terraform scripts (main.tf, variables.tf) and the documentation (README.md...)
- Added code to create Ethernet networks (dafault type only : "Tagged")
- Added local variables declaration
- Added documentation for Ethernet network module

## v1.0.1
- Added for each loop and list variables to handle the creation of multiple Eternet networks
- Added a local variables.tfvars file to set the configuration of the networks
- Added the parameter "ethernet_network_type" to be able to set network type to "Tunnel"
- Updated the README.md, REQUIREMENTS.md and RELEASE_NOTES.md files