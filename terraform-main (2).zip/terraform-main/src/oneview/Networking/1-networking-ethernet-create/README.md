## ** OneView Ethernet Networks Provisioning module**
### Euronext Usecase :
1-networking-Create-ethernet-network

This use case includes the Tunnel network use case.

### Description:
This Ethernet Networks Terraform module creates ethernet networks on OneView.

The configuration of the ethernet networks are provided as variables in the variables.tfvars file

### Workflow Pre-requistes :
- Initiate the terraform init, plan and apply command in the use case folder (1-networking-ethernet-create)

### Workflow Steps :
- If necessary, add or update the variables.tf file to change the ethernet networks configuration
- Create the ethernet networks

### Usage Example

```
$ cd Networking/1-networking-ethernet-create
$ terraform init
$ terraform plan -var-file=variables.tfvars
$ terraform apply -var-file=variables.tfvars
```

To destroy the resources created do the following:
```
$ cd Networking/1-networking-ethernet-create
$ terraform plan -destroy -var-file=variables.tfvars
$ terraform destroy -var-file=variables.tfvars
```

### Global Variables

Variables in the variables.tfvars file

| Variable name        | Comment | Type | Default Value |Example                       |
|----------------------|---------|------|---------------|------------------------------|-------------------------------------|
|`oneview_uri`|OneView URI|https://10.2.1.50/|||
|`oneview_username`|OneView Username|Administrator|||
|`oneview_password`|OneView Password||||
|`oneview_apiversion`|OneView API Version|2600|

### Local Variables

Variables are declared in the variables.tf file and set in the local variables.tfvars file.